# EE352 Final Project 
# May 9, 2015 
# Name: Anthony Wittemann 
# ID: 1704835940
# Email: awittema@usc.edu 
# Run in MARS
